﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Linq;

namespace setahajo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

  
    public partial class MainWindow : Window
    {
        List<Utazas> hajout = new List<Utazas>();
        public MainWindow()
        {
            InitializeComponent();
            foreach (var items in File.ReadAllLines(@"..\..\..\SRC\hajo.txt"))
            {
                hajout.Add(new Utazas(items));
            }

            if (hajout.Count > 0)
            {
                Random random = new Random();
                int index = random.Next(hajout.Count);
                Utazas ajanlat = hajout[index];
                ajanlateredmeny.Content = ajanlat;
            }

            foreach (var item in hajout)
            {
                hajovalasztas.Items.Add($"{item.hajonev}");
            }

        }

        public void KisHajokKiirasa()
        {
            var kisHajok = hajout.Where(h => h.maximalisutazasszam <= 6)
                                 .Select(h => $"{h.hajonev}, {h.napiberletdij} Ft");
            File.WriteAllLines(@"..\..\..\SRC\kishajok.txt", kisHajok);
        }

        private void szamolgomb_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(napszam.Text, out int napokSzama))
            {
                int osszKoltseg = hajout.Sum(h => h.KiszamolAr(napokSzama));
                koltsegeredmeny.Content = $"Összesen: {osszKoltseg} Ft";
            }
            else
            {
                koltsegeredmeny.Content = "Kérlek, adj meg érvényes számot!";
            }
        }

        private void keresogomb_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(utasszam.Text, out int valami))
            {
                var talalat = hajout.FirstOrDefault(h => h.maximalisutazasszam >= valami);
                if (talalat != null)
                {
                    eredmeny.Content = $"Talált hajó: {talalat.hajonev}, {talalat.maximalisutazasszam} fő, \n{talalat.napiberletdij} Ft/nap";
                }
                else
                {
                    eredmeny.Content = "Sajnos nem tudunk hajót ajánlani.";
                }
            }
            else
            {
                eredmeny.Content = "Kérlek adj meg érvényes számot!";
            }
        }
    }
}