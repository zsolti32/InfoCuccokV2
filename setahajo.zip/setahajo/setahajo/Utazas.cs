﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace setahajo
{
    public class Utazas
    {
        public int hajosorszam { get; set; }
        public string hajonev { get; set; }
        public string tipusa { get; set; }
        public int maximalisutazasszam { get; set; }
        public int napiberletdij { get; set; }
        public int NapokSzama { get; set; }

        public Utazas(string sor) 
        {
            var tomb = sor.Split(',');
            hajosorszam = int.Parse(tomb[0]);
            hajonev = tomb[1];
            tipusa = tomb[2];
            maximalisutazasszam = int.Parse(tomb[3]);
            napiberletdij = int.Parse(tomb[4]);
        }

        public override string ToString()
        {
            return $"{hajonev}";
        }

        public int KiszamolAr(int napokSzama)
        {
            return napokSzama * napiberletdij;
        }
    }
}
