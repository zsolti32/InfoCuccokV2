﻿namespace OscarWPF
{
    public class OscarDij
    {
        public string azon { get; set; }
        public string cim { get; set; }
        public int ev { get; set; }
        public int dij { get; set; }
        public int jelol { get; set; }
    
        public OscarDij(string sor) 
        {
            var tomb = sor.Split('\t');
            azon = tomb[0];
            cim = tomb[1];
            ev = int.Parse(tomb[2]);
            dij = int.Parse(tomb[3]);
            jelol = int.Parse(tomb[4]);
        }
    
    }



}