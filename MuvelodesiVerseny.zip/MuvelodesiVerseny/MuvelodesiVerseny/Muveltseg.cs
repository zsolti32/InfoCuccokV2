﻿namespace MuvelodesiVerseny
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Muveltseg
    {
        public string Kerdes { get; set; }
        public int Valasz { get; set; }
        public int Ertek { get; set; }
        public string Tantargy { get; set; }

        public Muveltseg(string sor)
        {
            var tomb = sor.Split(';');
            Kerdes = tomb[0];
            Valasz = int.Parse(tomb[1]);
            Ertek = int.Parse(tomb[2]);
            Tantargy = tomb[3];
        }
    }
}