﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace MuvelodesiVerseny
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }

            //1
            for (int i = 0; i < kerdoiv.Count; i++)
            {
                KerdesKiiras.Items.Add(kerdoiv[i].Kerdes);
            }
        }

        private void Torles_Click(object sender, RoutedEventArgs e)
        {
            KeresesKiras.Items.Clear();
        }

        private void ElsoGomb_Click(object sender, RoutedEventArgs e)
        {
            //2
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }
            var kerdojel = 0;
            for (int i = 0; i < kerdoiv.Count; i++)
            {
                if (kerdoiv[i].Kerdes.Contains("?"))
                {
                    kerdojel++;
                }
                KerdojelKiiras.Text = $"{kerdojel} db";
            }
        }

        private void MasodikFeladat_Click(object sender, RoutedEventArgs e)
        {
            //3
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }
            var kemiasfeladat = 0;
            for (int i = 0; i < kerdoiv.Count; i++)
            {
                if (kerdoiv[i].Ertek == 3 && kerdoiv[i].Tantargy == "kemia")
                {
                    kemiasfeladat++;
                }
                KemiaKiiras.Text = $"{kemiasfeladat} db";
            }
        }

        private void Harmadik_Click(object sender, RoutedEventArgs e)
        {

            //4
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }
            if (kerdoiv.Count > 0)
            {
                int minValasz = kerdoiv.Min(x => x.Valasz);
                int maxValasz = kerdoiv.Max(x => x.Valasz);

                SzamEredmeny.Text = $"A válaszok számértékei {minValasz} és {maxValasz} között terjednek.";
            }
        }

        private void ListaGomb_Click(object sender, RoutedEventArgs e)
        {
            //5
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }
            HashSet<string> TantargyKiiras = new HashSet<string>();
            for (int i = 0; i < kerdoiv.Count; i++)
            {
                TantargyKiiras.Add($"{kerdoiv[i].Tantargy}");
            }

            TantargyKiiras.Distinct();
            foreach (string tantargy in TantargyKiiras)
            {
                TemakorLista.Items.Add(tantargy);
            }
        }

        private void KeresGomb_Click(object sender, RoutedEventArgs e)
        {
            //6
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }

            string keresettSzo = KeresoBox.Text;
            foreach (var item in kerdoiv)
            {
                if (item.Kerdes.ToLower().Contains(keresettSzo))
                {
                    KeresesKiras.Items.Add(item.Kerdes);
                }
            }

            if (KerdesKiiras.Items.Count == 0)
            {
                MessageBox.Show("Hibás keresés, nincs találat!", "Hiba!", MessageBoxButton.OK);
            }
        }
        
        private void FeladatokGeneral_Click(object sender, RoutedEventArgs e)
        {
            //7
            List<Muveltseg> kerdoiv = new List<Muveltseg>();
            foreach (var item in File.ReadAllLines(@"..\..\..\feladatok.txt"))
            {
                kerdoiv.Add(new Muveltseg(item));
            }
            StreamWriter sw = new StreamWriter(@"..\..\..\15_feladat.txt");

            sw.Close();
        }
    }
}